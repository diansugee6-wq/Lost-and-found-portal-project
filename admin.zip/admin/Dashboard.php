<?php
// config.php
$servername = "localhost";
$username = "root";
$password = "";     // use your MySQL root password or empty string
$dbname = "lostfounddb";

// Create connection using mysqli
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --yellow: #fbb117;
            --white: #fff;
            --gray: #f5f5f5;
            --black1: #222;
        }

        body {
            min-height: 100vh;
            overflow: hidden;
            background: var(--gray);
        }

        .container {
            display: flex;
        }

        .navigation {
            width: 300px;
            height: 100vh;
            background: var(--yellow);
            border-left: 10px solid var(--yellow);
            overflow: hidden;
        }

        .navigation ul {
            margin: 0;
            padding: 0;
        }

        .navigation ul li {
            list-style: none;
        }

        .navigation ul li a {
            display: flex;
            align-items: center;
            padding: 25px 15px; 
            color: var(--black1);
            text-decoration: none;
            transition: 0.3s;
            border-top-left-radius: 40px;
            border-bottom-left-radius: 40px;
        }

        .navigation ul li a:hover,
        .navigation ul li a.hovered {
            background-color: #ffffff33;
        }

        .navigation ul li a.active {
            background-color: var(--gray);
        }

        .navigation ul li a .icon {
            min-width: 50px;
            text-align: center;
            font-size: 18px;
        }

        .navigation ul li a .title {
            font-size: 16px;
            font-weight: 500;
        }

        .logo-link {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 30px 15px;
            color: var(--black1);
            text-decoration: none;
        }

        .logo-link .icon img {
            display: block;
            width: 100px;
            height: 100px;
            object-fit: contain;
        }

        .logo-text {
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }

        .content {
            flex: 1;
            height: 100vh;
            background: var(--white);
            overflow: auto;
        }

        .content iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="navigation">
            <a href="#" class="logo-link">
                <span class="icon">
                    <img src="logo2.png" alt="Logo">
                </span>
                <span class="logo-text">Lost & Found inc.</span>
            </a>
            <ul>
                <li>
                    <a href="navdashboard.php" target="main-frame" class="active">
                        <span class="icon">📊</span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="contact%20us.png" target="main-frame">
                        <span class="icon">👤</span>
                        <span class="title">Profile</span>
                    </a>
                </li>
                <li>
                    <a href="contact%20us.png" target="main-frame">
                        <span class="icon">⚙</span>
                        <span class="title">Settings</span>
                    </a>
                </li>
                <li>
                    <a href="home.html" >
                        <span class="icon">🏠</span>
                        <span class="title">Back to Home</span>
                    </a>
                </li>
                <li>
                    <a href="contact%20us.png" target="main-frame">
                        <span class="icon">🚪</span>
                        <span class="title">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="content">
            <iframe name="main-frame" src="navdashboard.php"></iframe>
        </div>
    </div>

    <script>
        let list = document.querySelectorAll('.navigation ul li a');
        
        function activeLink() {
            list.forEach((item) => item.classList.remove("hovered"));
            this.classList.add("hovered");
        }
        
        list.forEach((item) => item.addEventListener("mouseover", activeLink));

        list.forEach((item) => {
            item.addEventListener("click", function() {
                list.forEach((link) => link.classList.remove("active"));
                this.classList.add("active");
            });
        });
    </script>
</body>
</html>